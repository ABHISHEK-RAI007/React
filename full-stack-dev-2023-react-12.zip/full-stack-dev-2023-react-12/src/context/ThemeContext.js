import { createContext } from "react";

const ThemeContext = createContext('lightMode')

export default ThemeContext;