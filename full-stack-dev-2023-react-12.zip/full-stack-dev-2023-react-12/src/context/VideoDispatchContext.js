import { createContext } from "react";

const VideoDispatchContext = createContext(null)

export default VideoDispatchContext;