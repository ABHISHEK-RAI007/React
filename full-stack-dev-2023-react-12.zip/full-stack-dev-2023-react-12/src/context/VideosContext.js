import { createContext } from "react";

const VideosContext = createContext(null)

export default VideosContext;