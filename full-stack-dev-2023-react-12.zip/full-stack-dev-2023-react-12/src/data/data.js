const videos = [{
    id:1,
    title: 'React JS tutorial',
    views: '999K',
    time: '1 year ago',
    channel: 'Coder Dost',
    verified: true
  },{
    id:2,  
    title: 'Node JS tutorial',
    views: '100K',
    time: '1 year ago',
    channel: 'Coder Dost',
    verified: false
  },
  { id:3,
    title: 'MongoDb JS tutorial',
    views: '1M',
    time: '1 month ago',
    channel: 'Coder Dost',
    verified: true
  }];

export default videos;